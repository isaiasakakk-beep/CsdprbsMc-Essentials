package br.com.csdprbsmc.essentials;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.geysermc.floodgate.api.FloodgateApi;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.cumulus.form.CustomForm;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class CsdprbsMcEssentials extends JavaPlugin implements Listener {
    private NamespacedKey compassKey;
    private File playerFile, clanFile, warpFile, tpaFile;
    private YamlConfiguration playerData, clanData, warpData, tpaData;
    private final Map<UUID, TpaRequest> tpaRequests = new HashMap<>(); // target -> pedido recebido
    private final Map<UUID, Long> tpaCooldowns = new HashMap<>();
    private static final long TPA_EXPIRY_MS = 60_000L;
    private static final long TPA_COOLDOWN_MS = 15_000L;
    private final Map<UUID, InputSession> inputSessions = new HashMap<>();
    private static final String TITLE = "CsdprbsMc Essentials";
    private static final String[] COLORS = {"AMARELO", "VERMELHO", "AZUL", "VERDE", "ROXO", "AQUA", "BRANCO"};
    private static final ChatColor[] CHAT_COLORS = {ChatColor.YELLOW, ChatColor.RED, ChatColor.BLUE, ChatColor.GREEN, ChatColor.DARK_PURPLE, ChatColor.AQUA, ChatColor.WHITE};
    // Preços em dinheiro do servidor. Venda paga 50% do preço de compra.
    private static final Material[][] SHOP_CATEGORIES = {
            {Material.COAL, Material.IRON_INGOT, Material.GOLD_INGOT, Material.COPPER_INGOT, Material.LAPIS_LAZULI, Material.REDSTONE, Material.DIAMOND, Material.EMERALD},
            {Material.OAK_LOG, Material.COBBLESTONE, Material.STONE, Material.GLASS, Material.BRICKS, Material.OBSIDIAN},
            {Material.WHEAT, Material.CARROT, Material.POTATO, Material.BEETROOT, Material.SUGAR_CANE, Material.PUMPKIN},
            {Material.BREAD, Material.COOKED_BEEF, Material.COOKED_CHICKEN, Material.GOLDEN_CARROT, Material.BAKED_POTATO},
            {Material.TORCH, Material.CHEST, Material.BARREL, Material.ANVIL, Material.ENCHANTING_TABLE},
            {Material.NAME_TAG, Material.SADDLE, Material.LEAD, Material.SHULKER_SHELL}
    };
    private static final String[] SHOP_CATEGORY_NAMES = {"MINÉRIOS", "CONSTRUÇÃO", "AGRICULTURA", "ALIMENTOS", "UTILIDADES", "ESPECIAIS LIMITADOS"};
    private static final double[][] SHOP_PRICES = {
            {5, 18, 30, 12, 10, 10, 180, 260},
            {6, 2, 4, 8, 14, 22},
            {4, 5, 5, 5, 6, 8},
            {8, 16, 12, 22, 8},
            {3, 20, 22, 180, 240},
            {250, 350, 80, 500}
    };
    private static final int[] SPECIAL_ITEM_LIMITS = {2, 1, 4, 1};

    @Override public void onEnable() {
        compassKey = new NamespacedKey(this, "exclusive_menu_compass");
        loadStores();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("CsdprbsMc Essentials habilitado. Faça backup e teste antes de abrir aos jogadores.");
    }

    @Override public void onDisable() { saveStores(); }

    private void loadStores() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        playerFile = new File(getDataFolder(), "players.yml");
        clanFile = new File(getDataFolder(), "clans.yml");
        warpFile = new File(getDataFolder(), "warps.yml");
        tpaFile = new File(getDataFolder(), "tpa.yml");
        playerData = YamlConfiguration.loadConfiguration(playerFile);
        clanData = YamlConfiguration.loadConfiguration(clanFile);
        warpData = YamlConfiguration.loadConfiguration(warpFile);
        tpaData = YamlConfiguration.loadConfiguration(tpaFile);
        tpaRequests.clear();
        long now = System.currentTimeMillis();
        for (String target : tpaData.getKeys(false)) {
            try {
                UUID targetId = UUID.fromString(target);
                UUID requesterId = UUID.fromString(tpaData.getString(target + ".requester", ""));
                long createdAt = tpaData.getLong(target + ".createdAt", 0L);
                if (createdAt > 0L && now - createdAt <= TPA_EXPIRY_MS) {
                    tpaRequests.put(targetId, new TpaRequest(requesterId, createdAt));
                }
            } catch (IllegalArgumentException ignored) { }
        }
        saveTpaRequests();
    }
    private void saveStores() {
        save(playerData, playerFile); save(clanData, clanFile); save(warpData, warpFile); saveTpaRequests();
    }
    private void saveTpaRequests() {
        if (tpaData == null || tpaFile == null) return;
        tpaData = new YamlConfiguration();
        for (Map.Entry<UUID, TpaRequest> entry : tpaRequests.entrySet()) {
            String key = entry.getKey().toString();
            tpaData.set(key + ".requester", entry.getValue().requester().toString());
            tpaData.set(key + ".createdAt", entry.getValue().createdAt());
        }
        save(tpaData, tpaFile);
    }
    private void save(YamlConfiguration y, File f) { try { y.save(f); } catch (IOException e) { getLogger().severe("Falha ao salvar " + f.getName() + ": " + e.getMessage()); } }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> {
            ensureCompass(p);
            updateTag(p);
            TpaRequest pending = getIncomingTpa(p.getUniqueId());
            if (pending != null) {
                Player requester = Bukkit.getPlayer(pending.requester());
                if (requester != null) p.sendMessage("§eVocê tem um pedido de TPA de " + requester.getName() + ". Abra a bússola > TPA para responder.");
            }
            for (Map.Entry<UUID, TpaRequest> entry : tpaRequests.entrySet()) {
                if (entry.getValue().requester().equals(p.getUniqueId())) {
                    Player target = Bukkit.getPlayer(entry.getKey());
                    if (target != null) target.sendMessage("§eO jogador " + p.getName() + " voltou. O pedido de TPA ainda está disponível; abra a bússola > TPA.");
                }
            }
        });
        String id = p.getUniqueId().toString();
        if (!playerData.contains(id + ".money")) playerData.set(id + ".money", 0.0);
        if (!playerData.contains(id + ".kills")) playerData.set(id + ".kills", 0);
        saveStores();
    }

    private ItemStack createCompass() {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("CsdprbsMc Menu", NamedTextColor.YELLOW).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
        meta.lore(List.of(Component.text("Menu exclusivo do servidor", NamedTextColor.GRAY)));
        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.getPersistentDataContainer().set(compassKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }
    private boolean isCompass(ItemStack item) {
        if (item == null || item.getType() != Material.RECOVERY_COMPASS || !item.hasItemMeta()) return false;
        Byte value = item.getItemMeta().getPersistentDataContainer().get(compassKey, PersistentDataType.BYTE);
        return value != null && value == (byte) 1;
    }
    private void ensureCompass(Player p) {
        PlayerInventory inventory = p.getInventory();
        ItemStack first = inventory.getItem(0);
        if (isCompass(first)) return;
        // Se a bússola já existir na mochila, troca de lugar com o item do primeiro slot.
        ItemStack[] storage = inventory.getStorageContents();
        for (int i = 1; i < storage.length; i++) {
            if (isCompass(storage[i])) {
                inventory.setItem(i, first);
                inventory.setItem(0, storage[i]);
                return;
            }
        }
        // Ao entregar pela primeira vez, preserva o item que já estava no primeiro slot.
        int empty = inventory.firstEmpty();
        if (empty >= 0) {
            if (first != null && !first.getType().isAir()) inventory.setItem(empty, first);
            inventory.setItem(0, createCompass());
            return;
        }
        if (inventory.getItemInOffHand() == null || inventory.getItemInOffHand().getType().isAir()) {
            inventory.setItemInOffHand(first);
            inventory.setItem(0, createCompass());
            return;
        }
        p.sendMessage("§eLibere um espaço no inventário para receber a bússola CsdprbsMc.");
    }
    @EventHandler public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isCompass(e.getItem())) return;
        e.setCancelled(true); openMain(e.getPlayer());
    }
    @EventHandler public void onDrop(PlayerDropItemEvent e) {
        if (isCompass(e.getItemDrop().getItemStack())) e.setCancelled(true);
        else Bukkit.getScheduler().runTask(this, () -> ensureCompass(e.getPlayer()));
    }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) {
        if (isCompass(e.getMainHandItem()) || isCompass(e.getOffHandItem())) e.setCancelled(true);
        else Bukkit.getScheduler().runTask(this, () -> ensureCompass(e.getPlayer()));
    }
    @EventHandler public void onInvClick(InventoryClickEvent e) {
        boolean protectedCompass = isCompass(e.getCurrentItem()) || isCompass(e.getCursor());
        if (!protectedCompass && e.getClick() == ClickType.NUMBER_KEY && e.getHotbarButton() == 0) {
            protectedCompass = isCompass(e.getWhoClicked().getInventory().getItem(0));
        }
        if (!protectedCompass && e.getClick() == ClickType.SWAP_OFFHAND && e.getWhoClicked() instanceof Player player) {
            protectedCompass = isCompass(player.getInventory().getItemInOffHand());
        }
        if (protectedCompass) e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!(e.getInventory().getHolder(false) instanceof MenuHolder holder)) {
            Bukkit.getScheduler().runTask(this, () -> ensureCompass(p));
            return;
        }
        e.setCancelled(true);
        if (e.getRawSlot() < 0 || e.getRawSlot() >= e.getInventory().getSize()) return;
        String action = holder.actions.get(e.getRawSlot());
        if (action != null) {
            if (action.startsWith("home:") && e.getClick().isRightClick()) handleAction(p, "home-set:" + action.substring(5));
            else handleAction(p, action);
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e) {
        if (isCompass(e.getOldCursor())) e.setCancelled(true);
        if (e.getInventory().getHolder(false) instanceof MenuHolder) e.setCancelled(true);
    }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { Bukkit.getScheduler().runTaskLater(this, () -> ensureCompass(e.getPlayer()), 1L); }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        UUID quitter = e.getPlayer().getUniqueId();
        inputSessions.remove(quitter);
        // Pedidos pendentes sobrevivem a saídas e reinícios enquanto estiverem dentro dos 60 segundos.
        // O pedido só pode ser aceito quando os dois jogadores estiverem online.
        tpaCooldowns.remove(quitter);
        saveTpaRequests();
    }

    @EventHandler public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isCompass);
        Player killer = e.getEntity().getKiller();
        if (killer != null) {
            String k = path(killer) + ".kills";
            playerData.set(k, playerData.getInt(k) + 1);
            saveStores();
        }
    }

    private boolean isBedrock(Player p) {
        if (!Bukkit.getPluginManager().isPluginEnabled("floodgate")) return false;
        try { return FloodgateApi.getInstance().isFloodgatePlayer(p.getUniqueId()); }
        catch (Throwable ignored) { return false; }
    }
    private void openMain(Player p) {
        if (isBedrock(p)) {
            SimpleForm.Builder f = SimpleForm.builder().title(TITLE).content("§l§eEscolha uma opção")
                    .button("§l§0TPA").button("§l§eHOME").button("§l§0WARPS")
                    .button("§l§eCLANS").button("§l§0RANKINGS").button("§l§eLOJA / ECONOMIA");
            List<String> actions = new ArrayList<>(List.of("tpa","homes","warps","clans","rankings","shop"));
            if (p.hasPermission("csdprbsmc.admin")) { f.button("§l§eADMINISTRAÇÃO"); actions.add("admin"); }
            f.validResultHandler(r -> { int n = r.clickedButtonId(); if (n >= 0 && n < actions.size()) handleAction(p, actions.get(n)); });
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), f);
        } else openJavaMenu(p, "main");
    }

    private void openJavaMenu(Player p, String page) {
        MenuHolder h = new MenuHolder();
        Inventory inv = Bukkit.createInventory(h, 27, Component.text(TITLE, NamedTextColor.YELLOW).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
        h.inventory = inv;
        for (int i=0;i<27;i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        if (page.equals("main")) {
            put(inv,h,10,Material.ENDER_PEARL,"§l§0TPA","tpa");
            put(inv,h,11,Material.RECOVERY_COMPASS,"§l§eHOME","homes");
            put(inv,h,12,Material.MAP,"§l§0WARPS","warps");
            put(inv,h,13,Material.SHIELD,"§l§eCLANS","clans");
            put(inv,h,14,Material.GOLD_INGOT,"§l§0RANKINGS","rankings");
            put(inv,h,15,Material.EMERALD,"§l§eLOJA / ECONOMIA","shop");
            if (p.hasPermission("csdprbsmc.admin")) put(inv,h,22,Material.COMMAND_BLOCK,"§l§eADMINISTRAÇÃO","admin");
        } else if (page.equals("homes")) {
            for(int i=1;i<=5;i++) put(inv,h,9+i,Material.RED_BED,"§l§eHOME "+i+" §7(esq: ir | dir: atualizar)", "home:"+i);
            put(inv,h,22,Material.ARROW,"§l§0VOLTAR","back");
        } else if (page.equals("warps")) {
            int slot=10; for(String key: warpData.getKeys(false)) { if(slot>16) break; put(inv,h,slot++,Material.ENDER_PEARL,"§l§0"+key,"warp:"+key); }
            put(inv,h,22,Material.ARROW,"§l§eVOLTAR","back");
        } else if (page.equals("clans")) {
            put(inv,h,11,Material.NAME_TAG,"§l§eCRIAR CLAN","clan:create");
            put(inv,h,13,Material.PLAYER_HEAD,"§l§0CONVITES","clan:invites");
            put(inv,h,14,Material.WRITABLE_BOOK,"§l§eCONVIDAR JOGADOR","clan:invite");
            put(inv,h,15,Material.LEATHER_CHESTPLATE,"§l§0COR DA TAG","clan:color");
            put(inv,h,16,Material.BARRIER,"§l§eSAIR DO CLAN","clan:leave");
            put(inv,h,22,Material.ARROW,"§l§0VOLTAR","back");
        } else if (page.equals("rankings")) {
            put(inv,h,11,Material.DIAMOND_SWORD,"§l§0TOP KILLS","rank:kills");
            put(inv,h,15,Material.GOLD_INGOT,"§l§eTOP MONEY","rank:money");
            put(inv,h,22,Material.ARROW,"§l§0VOLTAR","back");
        } else if (page.equals("shop")) {
            put(inv,h,10,Material.IRON_INGOT,"§l§0MINÉRIOS","shopcat:0");
            put(inv,h,11,Material.BRICKS,"§l§eCONSTRUÇÃO","shopcat:1");
            put(inv,h,12,Material.WHEAT,"§l§0AGRICULTURA","shopcat:2");
            put(inv,h,13,Material.COOKED_BEEF,"§l§eALIMENTOS","shopcat:3");
            put(inv,h,14,Material.CHEST,"§l§0UTILIDADES","shopcat:4");
            put(inv,h,15,Material.NAME_TAG,"§l§eESPECIAIS LIMITADOS","shopcat:5");
            put(inv,h,16,Material.GOLD_INGOT,"§l§0MEU SALDO: $"+getMoney(p),"shop:balance");
            put(inv,h,22,Material.ARROW,"§l§0VOLTAR","back");
        } else if (page.startsWith("shopcat:")) {
            int category = Integer.parseInt(page.substring(8));
            if (category >= 0 && category < SHOP_CATEGORIES.length) {
                Material[] items = SHOP_CATEGORIES[category];
                for (int i = 0; i < items.length; i++) {
                    double price = SHOP_PRICES[category][i];
                    int slot = 10 + i;
                    String limitText = category == 5 ? " §7Limite: " + getSpecialLimit(i) + " | Comprados: " + getSpecialBought(p, i) : "";
                    put(inv,h,slot,items[i],"§l§e"+items[i].name()+" §7Comprar: $"+price+limitText,"buy:"+category+":"+i);
                }
                put(inv,h,18,Material.HOPPER,"§l§0VENDER ITENS DESTA CATEGORIA","sellcat:"+category);
                put(inv,h,22,Material.ARROW,"§l§eVOLTAR","shop");
            }
        } else if (page.equals("admin")) {
            put(inv,h,10,Material.BEACON,"§l§0CRIAR WARP AQUI","admin:setwarp");
            put(inv,h,12,Material.GOLD_INGOT,"§l§eADICIONAR DINHEIRO","admin:money");
            put(inv,h,14,Material.TNT,"§l§0REMOVER WARP","admin:deletewarp");
            put(inv,h,16,Material.BARRIER,"§l§eRECARREGAR DADOS","admin:reload");
            put(inv,h,22,Material.ARROW,"§l§0VOLTAR","back");
        }
        p.openInventory(inv);
    }
    private void put(Inventory inv, MenuHolder h, int slot, Material mat, String title, String action) {
        inv.setItem(slot, named(mat,title,ChatColor.WHITE)); h.actions.put(slot,action);
    }
    private ItemStack named(Material m,String title,ChatColor color) {
        ItemStack it=new ItemStack(m); ItemMeta meta=it.getItemMeta(); meta.displayName(LegacyComponentSerializer.legacySection().deserialize(title)); it.setItemMeta(meta); return it;
    }
    private void handleAction(Player p,String action) {
        if(action.equals("back")) { openJavaMenu(p,"main"); return; }
        if(action.equals("input-confirm")) { finishInput(p); return; }
        if(action.equals("input-cancel")) { inputSessions.remove(p.getUniqueId()); openMain(p); return; }
        if(action.equals("input-backspace")) { editInput(p, "BACKSPACE"); return; }
        if(action.equals("input-clear")) { editInput(p, "CLEAR"); return; }
        if(action.startsWith("input-char:")) { editInput(p, action.substring(11)); return; }
        if(action.equals("tpa")) { openTpa(p, 0); return; }
        if(action.startsWith("tpa-page:")) { openTpa(p, Math.max(0, Integer.parseInt(action.substring(9)))); return; }
        if(action.startsWith("tpa-decline:")) { declineTpa(p, UUID.fromString(action.substring(12))); return; }
        if(action.equals("homes")) { if(isBedrock(p)) bedrockHomes(p); else openJavaMenu(p,"homes"); return; }
        if(action.equals("warps")) { openWarps(p, 0); return; }
        if(action.startsWith("warp-page:")) { openWarps(p, Math.max(0, Integer.parseInt(action.substring(10)))); return; }
        if(action.equals("clans")) { if(isBedrock(p)) bedrockClans(p); else openJavaMenu(p,"clans"); return; }
        if(action.equals("rankings")) { if(isBedrock(p)) bedrockRanks(p); else openJavaMenu(p,"rankings"); return; }
        if(action.equals("shop")) { if(isBedrock(p)) bedrockShop(p); else openJavaMenu(p,"shop"); return; }
        if(action.equals("shop:balance")) { p.sendMessage("§eSeu saldo: §a$"+String.format(Locale.US,"%.2f",getMoney(p))); return; }
        if(action.startsWith("shopcat:")) { openJavaMenu(p,action); return; }
        if(action.startsWith("sellcat:")) { sellCategory(p,Integer.parseInt(action.substring(8))); return; }
        if(action.equals("admin")) { if(!p.hasPermission("csdprbsmc.admin")){p.sendMessage("§cSem permissão.");return;} if(isBedrock(p))bedrockAdmin(p);else openJavaMenu(p,"admin"); return; }
        if(action.startsWith("home-set:")) {
            int n = Integer.parseInt(action.substring(9));
            if (n < 1 || n > 5) return;
            playerData.set(path(p) + ".homes." + n, p.getLocation());
            saveStores();
            p.sendMessage("§aHome " + n + " atualizada!");
            if (!isBedrock(p)) openJavaMenu(p, "homes"); else bedrockHomes(p);
            return;
        }
        if(action.startsWith("home:")) {
            int n = Integer.parseInt(action.substring(5));
            if (n < 1 || n > 5) return;
            String homePath = path(p) + ".homes." + n;
            if (playerData.contains(homePath)) {
                Location home = playerData.getLocation(homePath);
                if (home != null) p.teleport(home); else p.sendMessage("§cEssa home está inválida.");
            } else {
                playerData.set(homePath, p.getLocation());
                p.sendMessage("§eHome " + n + " definida!");
                saveStores();
                if (isBedrock(p)) bedrockHomes(p);
            }
            return;
        }
        if(action.startsWith("warp:")) { String name=action.substring(5); Location l=warpData.getLocation(name); if(l!=null) p.teleport(l); return; }
        if(action.startsWith("buy:")) { String[] parts=action.split(":"); if(parts.length==3) buy(p,Integer.parseInt(parts[1]),Integer.parseInt(parts[2])); return; }
        if(action.startsWith("rank:")) { showRank(p,action.substring(5)); return; }
        if(action.equals("clan:create")) { prompt(p,"Nome do clan (3 a 12 caracteres)", "clan-create"); return; }
        if(action.equals("clan:color")) { openColorMenu(p); return; }
        if(action.equals("clan:invite")) { openClanInviteMenu(p, 0); return; }
        if(action.startsWith("clan-invite-page:")) { openClanInviteMenu(p, Math.max(0, Integer.parseInt(action.substring(17)))); return; }
        if(action.equals("clan:invites")) { showInvites(p, 0); return; }
        if(action.startsWith("clan-invites-page:")) { showInvites(p, Math.max(0, Integer.parseInt(action.substring(18)))); return; }
        if(action.equals("clan:leave")) { leaveClan(p); return; }
        if(action.startsWith("color:")) { setClanColor(p,Integer.parseInt(action.substring(6))); return; }
        if(action.startsWith("clan-invite:")) { invite(p,UUID.fromString(action.substring(12))); return; }
        if(action.startsWith("tpa-send:")) { Player target=Bukkit.getPlayer(UUID.fromString(action.substring(9))); if(target!=null) sendTpa(p,target); return; }
        if(action.startsWith("tpa-accept:")) { acceptTpa(p,UUID.fromString(action.substring(11))); return; }
        if(action.startsWith("accept:")) { acceptInvite(p,UUID.fromString(action.substring(7))); return; }
        if(action.equals("admin:setwarp")) { prompt(p,"Nome da warp (até 24 caracteres)","warp-create"); return; }
        if(action.equals("admin:money")) { prompt(p,"Jogador;valor para adicionar dinheiro", "admin-money"); return; }
        if(action.equals("admin:deletewarp")) { prompt(p,"Nome da warp para remover", "warp-delete"); return; }
        if(action.equals("admin:reload")) { loadStores(); for (Player online : Bukkit.getOnlinePlayers()) updateTag(online); p.sendMessage("§aDados recarregados."); return; }
    }
    private String path(Player p) { return p.getUniqueId().toString(); }

    private void bedrockHomes(Player p) {
        SimpleForm.Builder form = SimpleForm.builder().title("HOMES").content("Até 5 homes. Escolha para teleportar ou atualizar.");
        List<String> actions = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            String homePath = path(p) + ".homes." + i;
            boolean exists = playerData.contains(homePath);
            form.button("HOME " + i + (exists ? " - TELEPORTAR" : " - DEFINIR"));
            actions.add("home:" + i);
            if (exists) {
                form.button("ATUALIZAR HOME " + i);
                actions.add("home-set:" + i);
            }
        }
        form.button("VOLTAR");
        form.validResultHandler(r -> {
            int clicked = r.clickedButtonId();
            if (clicked >= 0 && clicked < actions.size()) handleAction(p, actions.get(clicked));
            else if (clicked == actions.size()) openMain(p);
        });
        FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
    }
    private void bedrockWarps(Player p) { openWarps(p, 0); }

    private void openWarps(Player p, int page) {
        List<String> keys = new ArrayList<>(warpData.getKeys(false));
        keys.sort(String.CASE_INSENSITIVE_ORDER);
        int pageSize = isBedrock(p) ? 14 : 7;
        int maxPage = Math.max(0, (keys.size() - 1) / pageSize);
        int currentPage = Math.min(page, maxPage);
        int from = currentPage * pageSize;
        int to = Math.min(keys.size(), from + pageSize);
        List<String> visible = new ArrayList<>(keys.subList(from, to));
        if (isBedrock(p)) {
            SimpleForm.Builder form = SimpleForm.builder().title("WARPS")
                    .content("Destinos: " + keys.size() + " | Página " + (currentPage + 1) + "/" + (maxPage + 1));
            for (String key : visible) form.button(key);
            if (currentPage > 0) form.button("Página anterior");
            if (currentPage < maxPage) form.button("Próxima página");
            form.button("VOLTAR");
            final int backIndex = visible.size() + (currentPage > 0 ? 1 : 0) + (currentPage < maxPage ? 1 : 0);
            form.validResultHandler(r -> {
                int clicked = r.clickedButtonId();
                if (clicked >= 0 && clicked < visible.size()) {
                    Location location = warpData.getLocation(visible.get(clicked));
                    if (location != null) p.teleport(location);
                } else {
                    int previous = visible.size();
                    if (currentPage > 0 && clicked == previous) openWarps(p, currentPage - 1);
                    else if (currentPage < maxPage && clicked == previous + (currentPage > 0 ? 1 : 0)) openWarps(p, currentPage + 1);
                    else if (clicked == backIndex) openMain(p);
                }
            });
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
            return;
        }
        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("WARPS - Página " + (currentPage + 1)));
        holder.inventory = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        int slot = 10;
        for (String key : visible) put(inv, holder, slot++, Material.ENDER_PEARL, "§l§0" + key, "warp:" + key);
        if (currentPage > 0) put(inv, holder, 18, Material.ARROW, "§l§ePÁGINA ANTERIOR", "warp-page:" + (currentPage - 1));
        if (currentPage < maxPage) put(inv, holder, 26, Material.ARROW, "§l§0PRÓXIMA PÁGINA", "warp-page:" + (currentPage + 1));
        put(inv, holder, 4, Material.PAPER, "§l§eTOTAL: " + keys.size(), "warp-info");
        put(inv, holder, 22, Material.ARROW, "§l§eVOLTAR", "back");
        p.openInventory(inv);
    }

    private void bedrockClans(Player p) {
        SimpleForm.Builder f=SimpleForm.builder().title("CLANS").content("Sistema de clans").button("Criar clan").button("Convidar jogador").button("Escolher cor da tag").button("Ver convites").button("Sair do clan").button("VOLTAR");
        f.validResultHandler(r->{switch(r.clickedButtonId()){case 0->prompt(p,"Nome do clan (3 a 12 caracteres)","clan-create");case 1->openClanInviteMenu(p, 0);case 2->bedrockColor(p);case 3->showInvites(p, 0);case 4->leaveClan(p);case 5->openMain(p);}});
        FloodgateApi.getInstance().sendForm(p.getUniqueId(),f);
    }
    private void bedrockColor(Player p) {
        SimpleForm.Builder f=SimpleForm.builder().title("COR DA TAG").content("Escolha a cor da tag do seu clan."); for(String c:COLORS) f.button(c);
        f.button("VOLTAR");
        f.validResultHandler(r->{int i=r.clickedButtonId();if(i>=0&&i<COLORS.length)setClanColor(p,i);else if(i==COLORS.length)bedrockClans(p);}); FloodgateApi.getInstance().sendForm(p.getUniqueId(),f);
    }
    private void openClanInviteMenu(Player p, int page) {
        if (findClan(p.getUniqueId()) == null) { p.sendMessage("§cVocê não está em um clan."); return; }
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        online.removeIf(q -> q.getUniqueId().equals(p.getUniqueId()));
        online.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        int pageSize = isBedrock(p) ? 14 : 7;
        int maxPage = Math.max(0, (online.size() - 1) / pageSize);
        int currentPage = Math.min(page, maxPage);
        int from = currentPage * pageSize;
        List<Player> visible = new ArrayList<>(online.subList(from, Math.min(online.size(), from + pageSize)));
        if (isBedrock(p)) {
            SimpleForm.Builder form = SimpleForm.builder().title("CONVIDAR JOGADOR")
                    .content("Jogadores online: " + online.size() + " | Página " + (currentPage + 1) + "/" + (maxPage + 1));
            for (Player target : visible) form.button(target.getName());
            int previous = -1, next = -1;
            if (currentPage > 0) { previous = visible.size(); form.button("Página anterior"); }
            if (currentPage < maxPage) { next = visible.size() + (currentPage > 0 ? 1 : 0); form.button("Próxima página"); }
            form.button("VOLTAR");
            final int prevIndex = previous, nextIndex = next, backIndex = visible.size() + (currentPage > 0 ? 1 : 0) + (currentPage < maxPage ? 1 : 0);
            form.validResultHandler(r -> {
                int clicked = r.clickedButtonId();
                if (clicked >= 0 && clicked < visible.size()) invite(p, visible.get(clicked).getUniqueId());
                else if (clicked == prevIndex) openClanInviteMenu(p, currentPage - 1);
                else if (clicked == nextIndex) openClanInviteMenu(p, currentPage + 1);
                else if (clicked == backIndex) bedrockClans(p);
            });
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
            return;
        }
        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Convidar para clan - Página " + (currentPage + 1)));
        holder.inventory = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        int slot = 10;
        for (Player target : visible) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            if (head.getItemMeta() instanceof org.bukkit.inventory.meta.SkullMeta skull) {
                skull.setOwningPlayer(target);
                skull.displayName(LegacyComponentSerializer.legacySection().deserialize("§l§e" + target.getName()));
                head.setItemMeta(skull);
            }
            inv.setItem(slot, head);
            holder.actions.put(slot++, "clan-invite:" + target.getUniqueId());
        }
        if (currentPage > 0) put(inv, holder, 18, Material.ARROW, "§l§ePÁGINA ANTERIOR", "clan-invite-page:" + (currentPage - 1));
        if (currentPage < maxPage) put(inv, holder, 26, Material.ARROW, "§l§0PRÓXIMA PÁGINA", "clan-invite-page:" + (currentPage + 1));
        put(inv, holder, 22, Material.ARROW, "§l§eVOLTAR", "clans");
        p.openInventory(inv);
    }
    private void openColorMenu(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Cor da tag"));
        h.inventory = inv;
        for (int i = 0; i < COLORS.length; i++) put(inv, h, 10 + i, Material.LEATHER_CHESTPLATE, "§l§e" + COLORS[i], "color:" + i);
        put(inv, h, 22, Material.ARROW, "§l§0VOLTAR", "clans");
        p.openInventory(inv);
    }
    private void setClanColor(Player p,int i) {
        String clan=findClan(p.getUniqueId()); if(clan==null){p.sendMessage("§cVocê não está em um clan.");return;}
        clanData.set(clan + ".color", i);
        saveStores();
        for (String member : clanData.getStringList(clan + ".members")) {
            try {
                Player online = Bukkit.getPlayer(UUID.fromString(member));
                if (online != null) updateTag(online);
            } catch (IllegalArgumentException ignored) { }
        }
        p.sendMessage("§aA cor da tag do clan foi atualizada!");
    }
    private void bedrockRanks(Player p) {
        SimpleForm.Builder f=SimpleForm.builder().title("RANKINGS").content("Escolha o ranking.").button("Top 10 Kills").button("Top 10 Money").button("VOLTAR");
        f.validResultHandler(r->{if(r.clickedButtonId()==0)showRank(p,"kills");if(r.clickedButtonId()==1)showRank(p,"money");if(r.clickedButtonId()==2)openMain(p);});
        FloodgateApi.getInstance().sendForm(p.getUniqueId(),f);
    }
    private void bedrockAdmin(Player p) {
        SimpleForm.Builder f=SimpleForm.builder().title("ADMINISTRAÇÃO").content("Ferramentas administrativas")
                .button("Criar warp na minha posição").button("Adicionar dinheiro a jogador").button("Remover warp").button("Recarregar dados").button("VOLTAR");
        f.validResultHandler(r->{switch(r.clickedButtonId()){
            case 0->prompt(p,"Nome da warp (até 24 caracteres)","warp-create");
            case 1->prompt(p,"Jogador;valor para adicionar dinheiro", "admin-money");
            case 2->prompt(p,"Nome da warp para remover", "warp-delete");
            case 3->{loadStores();for(Player online:Bukkit.getOnlinePlayers())updateTag(online);p.sendMessage("§aDados recarregados.");}
            case 4->openMain(p);
        }});
        FloodgateApi.getInstance().sendForm(p.getUniqueId(),f);
    }
    private void bedrockShop(Player p) {
        SimpleForm.Builder f=SimpleForm.builder().title("LOJA / ECONOMIA").content("Saldo: $"+String.format(Locale.US,"%.2f",getMoney(p))+"\nEscolha uma categoria:");
        for(String category:SHOP_CATEGORY_NAMES) f.button(category);
        f.button("VOLTAR");
        f.validResultHandler(r->{int i=r.clickedButtonId();if(i>=0&&i<SHOP_CATEGORIES.length)bedrockShopCategory(p,i);else if(i==SHOP_CATEGORIES.length)openMain(p);});
        FloodgateApi.getInstance().sendForm(p.getUniqueId(),f);
    }
    private void bedrockShopCategory(Player p,int category) {
        SimpleForm.Builder f=SimpleForm.builder().title(SHOP_CATEGORY_NAMES[category]).content("Saldo: $"+String.format(Locale.US,"%.2f",getMoney(p))+"\nEscolha para comprar. A venda paga 50% do preço.");
        for(int i=0;i<SHOP_CATEGORIES[category].length;i++) {
            String limitText = category == 5 ? " - LIMITE " + getSpecialLimit(i) + " (" + getSpecialBought(p, i) + " comprados)" : "";
            f.button(SHOP_CATEGORIES[category][i].name()+" - $"+SHOP_PRICES[category][i]+limitText);
        }
        f.button("VENDER ITENS DESTA CATEGORIA");
        f.button("VOLTAR À LOJA");
        f.validResultHandler(r->{int i=r.clickedButtonId();if(i>=0&&i<SHOP_CATEGORIES[category].length){buy(p,category,i);bedrockShopCategory(p,category);}else if(i==SHOP_CATEGORIES[category].length){sellCategory(p,category);bedrockShopCategory(p,category);}else if(i==SHOP_CATEGORIES[category].length+1)bedrockShop(p);});
        FloodgateApi.getInstance().sendForm(p.getUniqueId(),f);
    }

    private void openTpa(Player p, int page) {
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        online.removeIf(q -> q.getUniqueId().equals(p.getUniqueId()));
        online.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        final int pageSize = isBedrock(p) ? 14 : 7;
        int maxPage = Math.max(0, (online.size() - 1) / pageSize);
        int currentPage = Math.min(page, maxPage);
        int from = currentPage * pageSize;
        int to = Math.min(online.size(), from + pageSize);
        List<Player> visible = new ArrayList<>(online.subList(from, to));
        TpaRequest incoming = getIncomingTpa(p.getUniqueId());
        Player requester = incoming == null ? null : Bukkit.getPlayer(incoming.requester());

        if (isBedrock(p)) {
            SimpleForm.Builder form = SimpleForm.builder().title("TPA")
                    .content("Jogadores online: " + online.size() + " | Página " + (currentPage + 1) + "/" + (maxPage + 1));
            for (Player target : visible) form.button("Enviar TPA: " + target.getName());
            int acceptIndex = -1;
            int declineIndex = -1;
            if (requester != null) {
                acceptIndex = visible.size();
                form.button("ACEITAR TPA: " + requester.getName());
                declineIndex = visible.size() + 1;
                form.button("RECUSAR TPA: " + requester.getName());
            }
            int previousIndex = -1;
            int nextIndex = -1;
            if (currentPage > 0) { previousIndex = visible.size() + (requester == null ? 0 : 2); form.button("Página anterior"); }
            if (currentPage < maxPage) { nextIndex = visible.size() + (requester == null ? 0 : 2) + (currentPage > 0 ? 1 : 0); form.button("Próxima página"); }
            form.button("VOLTAR");
            final int backIndex = visible.size() + (requester == null ? 0 : 2) + (currentPage > 0 ? 1 : 0) + (currentPage < maxPage ? 1 : 0);
            final int accept = acceptIndex, decline = declineIndex, previous = previousIndex, next = nextIndex;
            final UUID requesterId = requester == null ? null : requester.getUniqueId();
            form.validResultHandler(r -> {
                int clicked = r.clickedButtonId();
                if (clicked >= 0 && clicked < visible.size()) {
                    Player target = Bukkit.getPlayer(visible.get(clicked).getUniqueId());
                    if (target != null) sendTpa(p, target);
                } else if (clicked == accept && requesterId != null) acceptTpa(p, requesterId);
                else if (clicked == decline && requesterId != null) declineTpa(p, requesterId);
                else if (clicked == previous) openTpa(p, currentPage - 1);
                else if (clicked == next) openTpa(p, currentPage + 1);
                else if (clicked == backIndex) openMain(p);
            });
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
            return;
        }

        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("TPA - Jogadores online"));
        holder.inventory = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        int slot = 10;
        for (Player target : visible) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            if (head.getItemMeta() instanceof org.bukkit.inventory.meta.SkullMeta skull) {
                skull.setOwningPlayer(target);
                skull.displayName(LegacyComponentSerializer.legacySection().deserialize("§l§0" + target.getName()));
                head.setItemMeta(skull);
            }
            inv.setItem(slot, head);
            holder.actions.put(slot, "tpa-send:" + target.getUniqueId());
            slot++;
        }
        if (requester != null) {
            put(inv, holder, 22, Material.LIME_DYE, "§l§eACEITAR " + requester.getName(), "tpa-accept:" + requester.getUniqueId());
            put(inv, holder, 23, Material.RED_DYE, "§l§0RECUSAR " + requester.getName(), "tpa-decline:" + requester.getUniqueId());
        }
        if (currentPage > 0) put(inv, holder, 18, Material.ARROW, "§l§ePÁGINA ANTERIOR", "tpa-page:" + (currentPage - 1));
        if (currentPage < maxPage) put(inv, holder, 26, Material.ARROW, "§l§0PRÓXIMA PÁGINA", "tpa-page:" + (currentPage + 1));
        put(inv, holder, 4, Material.PAPER, "§l§eONLINE: " + online.size() + " | PÁGINA " + (currentPage + 1) + "/" + (maxPage + 1), "tpa-info");
        put(inv, holder, 21, Material.ARROW, "§l§eVOLTAR", "back");
        p.openInventory(inv);
    }

    private TpaRequest getIncomingTpa(UUID target) {
        TpaRequest request = tpaRequests.get(target);
        if (request != null && (System.currentTimeMillis() < request.createdAt() || System.currentTimeMillis() - request.createdAt() > TPA_EXPIRY_MS)) {
            tpaRequests.remove(target);
            saveTpaRequests();
            return null;
        }
        return request;
    }
    private void sendTpa(Player from,Player to){
        if(from.equals(to)) return;
        if (!from.isOnline() || !to.isOnline()) { from.sendMessage("§cEsse jogador não está mais online."); return; }
        if (tpaRequests.containsKey(to.getUniqueId()) && getIncomingTpa(to.getUniqueId()) != null) {
            from.sendMessage("§cEsse jogador já tem um pedido de TPA pendente.");
            return;
        }
        long now=System.currentTimeMillis();
        long last=tpaCooldowns.getOrDefault(from.getUniqueId(),0L);
        if(now-last<TPA_COOLDOWN_MS){from.sendMessage("§cAguarde alguns segundos antes de enviar outro TPA.");return;}
        tpaCooldowns.put(from.getUniqueId(),now);
        tpaRequests.put(to.getUniqueId(),new TpaRequest(from.getUniqueId(),now));
        saveTpaRequests();
        from.sendMessage("§ePedido de TPA enviado para "+to.getName()+". Ele expira em 60 segundos.");
        to.sendMessage("§e"+from.getName()+" pediu para teleportar até você. Abra a bússola > TPA para aceitar (60 segundos).");
    }
    private void acceptTpa(Player target,UUID requesterId){
        TpaRequest request=getIncomingTpa(target.getUniqueId());
        if(request==null||!request.requester().equals(requesterId)){target.sendMessage("§cEsse pedido expirou ou não está mais disponível.");return;}
        Player requester=Bukkit.getPlayer(requesterId);
        if(requester==null){target.sendMessage("§cO jogador saiu do servidor.");tpaRequests.remove(target.getUniqueId());saveTpaRequests();return;}
        boolean teleported = requester.teleport(target.getLocation());
        if (teleported) {
            requester.sendMessage("§aTPA aceito!");
            target.sendMessage("§aPedido aceito.");
        } else {
            target.sendMessage("§cNão foi possível teleportar o jogador.");
            requester.sendMessage("§cO teleporte não foi concluído.");
        }
        tpaRequests.remove(target.getUniqueId());
        saveTpaRequests();
    }
    private void declineTpa(Player target, UUID requesterId) {
        TpaRequest request = getIncomingTpa(target.getUniqueId());
        if (request == null || !request.requester().equals(requesterId)) {
            target.sendMessage("§cEsse pedido expirou ou não está mais disponível.");
            return;
        }
        Player requester = Bukkit.getPlayer(requesterId);
        if (requester != null) requester.sendMessage("§cSeu pedido de TPA foi recusado.");
        target.sendMessage("§ePedido de TPA recusado.");
        tpaRequests.remove(target.getUniqueId());
        saveTpaRequests();
    }
    private void showInvites(Player p, int page) {
        List<String> invitations = new ArrayList<>(clanData.getStringList("invites." + p.getUniqueId()));
        invitations.removeIf(id -> !clanData.contains(id + ".name"));
        invitations.sort(Comparator.comparing(id -> clanData.getString(id + ".name", id), String.CASE_INSENSITIVE_ORDER));
        if (invitations.isEmpty()) {
            p.sendMessage("§7Você não tem convites.");
            if (isBedrock(p)) bedrockClans(p); else openJavaMenu(p, "clans");
            return;
        }
        int pageSize = isBedrock(p) ? 14 : 7;
        int maxPage = Math.max(0, (invitations.size() - 1) / pageSize);
        int currentPage = Math.min(page, maxPage);
        int from = currentPage * pageSize;
        List<String> visible = new ArrayList<>(invitations.subList(from, Math.min(invitations.size(), from + pageSize)));
        if (isBedrock(p)) {
            SimpleForm.Builder form = SimpleForm.builder().title("CONVITES DE CLAN")
                    .content("Convites: " + invitations.size() + " | Página " + (currentPage + 1) + "/" + (maxPage + 1));
            for (String clan : visible) form.button(clanData.getString(clan + ".name", clan));
            int previous = -1, next = -1;
            if (currentPage > 0) { previous = visible.size(); form.button("Página anterior"); }
            if (currentPage < maxPage) { next = visible.size() + (currentPage > 0 ? 1 : 0); form.button("Próxima página"); }
            form.button("VOLTAR");
            final int prevIndex = previous, nextIndex = next;
            final int backIndex = visible.size() + (currentPage > 0 ? 1 : 0) + (currentPage < maxPage ? 1 : 0);
            form.validResultHandler(r -> {
                int clicked = r.clickedButtonId();
                if (clicked >= 0 && clicked < visible.size()) acceptInvite(p, UUID.fromString(visible.get(clicked)));
                else if (clicked == prevIndex) showInvites(p, currentPage - 1);
                else if (clicked == nextIndex) showInvites(p, currentPage + 1);
                else if (clicked == backIndex) bedrockClans(p);
            });
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
            return;
        }
        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Convites de clan - Página " + (currentPage + 1)));
        holder.inventory = inv;
        for (int i = 0; i < 27; i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        int slot = 10;
        for (String clan : visible) {
            String owner = clanData.getString(clan + ".owner");
            if (owner != null) put(inv, holder, slot++, Material.SHIELD, "§l§e" + clanData.getString(clan + ".name", clan), "accept:" + owner);
        }
        if (currentPage > 0) put(inv, holder, 18, Material.ARROW, "§l§ePÁGINA ANTERIOR", "clan-invites-page:" + (currentPage - 1));
        if (currentPage < maxPage) put(inv, holder, 26, Material.ARROW, "§l§0PRÓXIMA PÁGINA", "clan-invites-page:" + (currentPage + 1));
        put(inv, holder, 22, Material.ARROW, "§l§eVOLTAR", "clans");
        p.openInventory(inv);
    }

    private void acceptInvite(Player p,UUID owner){
        String clan=owner.toString();
        if(!clanData.contains(clan+".name")){p.sendMessage("§cConvite inválido.");return;}
        List<String> inv=clanData.getStringList("invites."+p.getUniqueId());
        if(!inv.contains(clan)){p.sendMessage("§cVocê não tem um convite válido para esse clan.");return;}
        List<String> members=clanData.getStringList(clan+".members");
        if(members.size()>=8){p.sendMessage("§cEsse clan já tem 8 membros.");return;}
        if(findClan(p.getUniqueId())!=null){p.sendMessage("§cVocê já está em um clan.");return;}
        if(!members.contains(p.getUniqueId().toString())) members.add(p.getUniqueId().toString());
        clanData.set(clan+".members",members);
        inv.remove(clan);clanData.set("invites."+p.getUniqueId(),inv);
        saveStores();updateTag(p);p.sendMessage("§aVocê entrou no clan!");
    }
    private void invite(Player p,UUID target){
        String clan=findClan(p.getUniqueId());
        if(clan==null){p.sendMessage("§cVocê não está em um clan.");return;}
        if(!Objects.equals(clanData.getString(clan+".owner"),p.getUniqueId().toString())){p.sendMessage("§cSomente o líder pode convidar.");return;}
        List<String> members = clanData.getStringList(clan + ".members");
        if (members.size() >= 8) { p.sendMessage("§cSeu clan já atingiu o limite de 8 membros."); return; }
        if (members.contains(target.toString())) { p.sendMessage("§cEsse jogador já está no clan."); return; }
        Player t=Bukkit.getPlayer(target);
        if(t==null){p.sendMessage("§cEsse jogador não está online.");return;}
        if(findClan(target)!=null){p.sendMessage("§cEsse jogador já pertence a um clan.");return;}
        List<String> inv=clanData.getStringList("invites."+target);
        if(inv.contains(clan)){p.sendMessage("§cEsse jogador já recebeu um convite.");return;}
        inv.add(clan);clanData.set("invites."+target,inv);saveStores();
        t.sendMessage("§eVocê recebeu um convite de clan. Abra a bússola > Clans > Convites.");p.sendMessage("§aConvite enviado.");
    }
    private void createClan(Player p,String name){name=name.trim().replaceAll("[^A-Za-z0-9_-]", "");if(name.length()<3||name.length()>12){p.sendMessage("§cO nome deve ter de 3 a 12 caracteres (letras, números, _ ou -).");return;}if(findClan(p.getUniqueId())!=null){p.sendMessage("§cVocê já está em um clan.");return;}for(String existing:clanData.getKeys(false)){if(!existing.equals("invites")&&clanData.getString(existing+".name","").equalsIgnoreCase(name)){p.sendMessage("§cEsse nome de clan já está sendo usado.");return;}}String id=p.getUniqueId().toString();if(clanData.contains(id+".name")){p.sendMessage("§cVocê já criou um clan.");return;}clanData.set(id+".name",name);clanData.set(id+".owner",id);clanData.set(id+".members",List.of(id));clanData.set(id+".color",0);saveStores();updateTag(p);p.sendMessage("§aClan criado: "+name);}
    private void leaveClan(Player p) {
        String clan = findClan(p.getUniqueId());
        if (clan == null) { p.sendMessage("§cVocê não está em um clan."); return; }
        String playerId = p.getUniqueId().toString();
        if (Objects.equals(clanData.getString(clan + ".owner"), playerId)) {
            List<String> members = new ArrayList<>(clanData.getStringList(clan + ".members"));
            clanData.set(clan, null);
            var invitationSection = clanData.getConfigurationSection("invites");
            if (invitationSection != null) {
                for (String invited : new ArrayList<>(invitationSection.getKeys(false))) {
                    List<String> invites = clanData.getStringList("invites." + invited);
                    invites.remove(clan);
                    clanData.set("invites." + invited, invites);
                }
            }
            for (String member : members) {
                Player online = Bukkit.getPlayer(UUID.fromString(member));
                if (online != null) { updateTag(online); online.sendMessage("§eO clan foi encerrado pelo líder."); }
            }
            p.sendMessage("§eVocê encerrou seu clan.");
        } else {
            List<String> members = new ArrayList<>(clanData.getStringList(clan + ".members"));
            members.remove(playerId);
            clanData.set(clan + ".members", members);
            updateTag(p);
            p.sendMessage("§eVocê saiu do clan.");
        }
        saveStores();
    }

    private String findClan(UUID uuid){String u=uuid.toString();for(String key:clanData.getKeys(false)){if(key.equals("invites"))continue;if(clanData.getStringList(key+".members").contains(u))return key;}return null;}

    private void prompt(Player p, String message, String type) {
        if (isBedrock(p)) {
            CustomForm.Builder form = CustomForm.builder().title("CsdprbsMc - Entrada")
                    .input(message, "Digite aqui", "");
            form.validResultHandler(response -> {
                completeInput(p, type, response.asInput(0));
                openMain(p);
            });
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
            return;
        }
        inputSessions.put(p.getUniqueId(), new InputSession(type));
        openKeyboard(p);
    }

    private void openKeyboard(Player p) {
        InputSession session = inputSessions.get(p.getUniqueId());
        if (session == null) return;
        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text("Digite pelo menu"));
        holder.inventory = inv;
        for (int i = 0; i < 54; i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        put(inv, holder, 4, Material.PAPER, "§l§eTEXTO: " + (session.value.isEmpty() ? "_" : session.value), "input-info");
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int[] letterSlots = {10,11,12,13,14,15,16,19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41};
        for (int i = 0; i < chars.length(); i++) {
            String c = String.valueOf(chars.charAt(i));
            put(inv, holder, letterSlots[i], Material.LIGHT_BLUE_STAINED_GLASS_PANE, "§l§0" + c, "input-char:" + c);
        }
        String digits = "0123456789";
        for (int i = 0; i < digits.length(); i++) {
            String c = String.valueOf(digits.charAt(i));
            put(inv, holder, i, Material.WHITE_STAINED_GLASS_PANE, "§l§0" + c, "input-char:" + c);
        }
        put(inv, holder, 42, Material.YELLOW_STAINED_GLASS_PANE, "§l§0_", "input-char:_");
        put(inv, holder, 43, Material.YELLOW_STAINED_GLASS_PANE, "§l§0-", "input-char:-");
        put(inv, holder, 44, Material.YELLOW_STAINED_GLASS_PANE, "§l§0.", "input-char:.");
        put(inv, holder, 45, Material.YELLOW_STAINED_GLASS_PANE, "§l§0;", "input-char:;");
        put(inv, holder, 47, Material.ARROW, "§l§eAPAGAR ÚLTIMO", "input-backspace");
        put(inv, holder, 48, Material.BARRIER, "§l§0LIMPAR", "input-clear");
        put(inv, holder, 50, Material.RED_DYE, "§l§0CANCELAR", "input-cancel");
        put(inv, holder, 52, Material.LIME_DYE, "§l§eCONFIRMAR", "input-confirm");
        p.openInventory(inv);
    }

    private void editInput(Player p, String value) {
        InputSession session = inputSessions.get(p.getUniqueId());
        if (session == null) return;
        if (value.equals("BACKSPACE")) {
            if (!session.value.isEmpty()) session.value = session.value.substring(0, session.value.length() - 1);
        } else if (value.equals("CLEAR")) session.value = "";
        else {
            int limit = session.type.equals("admin-money") ? 40 : 16;
            if (session.value.length() < limit) session.value += value.toLowerCase(Locale.ROOT);
        }
        openKeyboard(p);
    }

    private void finishInput(Player p) {
        InputSession session = inputSessions.remove(p.getUniqueId());
        if (session == null) return;
        completeInput(p, session.type, session.value);
        openMain(p);
    }

    private void completeInput(Player p, String type, String raw) {
        if (raw == null || raw.isBlank()) { p.sendMessage("§cNenhum texto foi informado."); return; }
        String value = raw.trim();
        if (type.equals("clan-create")) createClan(p, value);
        else if (type.equals("warp-create")) {
            if (!p.hasPermission("csdprbsmc.admin")) { p.sendMessage("§cSem permissão."); return; }
            String name = value.replaceAll("[^A-Za-z0-9_-]", "");
            if (name.isBlank() || name.length() > 24) { p.sendMessage("§cNome de warp inválido (máximo 24 caracteres)."); return; }
            if (warpData.contains(name)) { p.sendMessage("§cJá existe uma warp com esse nome."); return; }
            warpData.set(name, p.getLocation()); saveStores(); p.sendMessage("§aWarp criada: " + name);
        } else if (type.equals("warp-delete")) {
            if (!p.hasPermission("csdprbsmc.admin")) { p.sendMessage("§cSem permissão."); return; }
            String name = value.replaceAll("[^A-Za-z0-9_-]", "");
            if (name.isBlank() || !warpData.contains(name)) { p.sendMessage("§cEssa warp não existe."); return; }
            warpData.set(name, null);
            saveStores();
            p.sendMessage("§aWarp removida: " + name);
        } else if (type.equals("admin-money")) {
            if (!p.hasPermission("csdprbsmc.admin")) return;
            String[] parts = value.split(";");
            if (parts.length != 2) { p.sendMessage("§cFormato inválido. Use NOME;VALOR no próprio teclado do menu."); return; }
            Player target = Bukkit.getOnlinePlayers().stream().filter(player -> player.getName().equalsIgnoreCase(parts[0].trim())).findFirst().orElse(null);
            try {
                double amount = Double.parseDouble(parts[1].trim());
                if (target == null || !Double.isFinite(amount) || amount <= 0) {
                    p.sendMessage("§cJogador online ou valor positivo inválido."); return;
                }
                setMoney(target, getMoney(target) + amount);
                p.sendMessage("§aSaldo atualizado para " + target.getName() + ".");
                target.sendMessage("§aUm administrador atualizou seu saldo.");
            } catch (NumberFormatException ex) { p.sendMessage("§cValor inválido."); }
        }
    }

    private int getSpecialLimit(int index) { return index >= 0 && index < SPECIAL_ITEM_LIMITS.length ? SPECIAL_ITEM_LIMITS[index] : 0; }
    private int getSpecialBought(Player p, int index) {
        if (index < 0 || index >= SHOP_CATEGORIES[5].length) return 0;
        return playerData.getInt(path(p) + ".specialBought." + SHOP_CATEGORIES[5][index].name(), 0);
    }
    private double getMoney(Player p){return playerData.getDouble(path(p)+".money",0);}
    private void setMoney(Player p,double v){if(!Double.isFinite(v)||v<0){p.sendMessage("§cValor de saldo inválido.");return;}playerData.set(path(p)+".money",v);saveStores();}
    private void buy(Player p,int category,int index) {
        if(category<0||category>=SHOP_CATEGORIES.length||index<0||index>=SHOP_CATEGORIES[category].length)return;
        Material material=SHOP_CATEGORIES[category][index]; double price=SHOP_PRICES[category][index];
        if (category == 5 && getSpecialBought(p, index) >= getSpecialLimit(index)) {
            p.sendMessage("§cVocê já atingiu o limite desse item especial.");
            return;
        }
        if(getMoney(p)<price){p.sendMessage("§cDinheiro insuficiente.");return;}
        Map<Integer,ItemStack> leftovers=p.getInventory().addItem(new ItemStack(material,1));
        if(!leftovers.isEmpty()){p.sendMessage("§cSeu inventário está cheio.");return;}
        setMoney(p,getMoney(p)-price);
        if (category == 5) playerData.set(path(p) + ".specialBought." + material.name(), getSpecialBought(p, index) + 1);
        saveStores();
        p.sendMessage("§aComprado: "+material.name()+" por $"+price);
        if (!isBedrock(p)) openJavaMenu(p, "shopcat:" + category);
    }
    private void sellCategory(Player p,int category) {
        if(category<0||category>=SHOP_CATEGORIES.length)return;
        double total=0; int amount=0;
        for(int i=0;i<SHOP_CATEGORIES[category].length;i++) {
            Material material=SHOP_CATEGORIES[category][i]; double unit=SHOP_PRICES[category][i]*0.5;
            ItemStack[] contents=p.getInventory().getStorageContents();
            for(int slot=0;slot<contents.length;slot++) {
                ItemStack stack=contents[slot];
                if(stack!=null&&stack.isSimilar(new ItemStack(material))) {int count=stack.getAmount();total+=count*unit;amount+=count;p.getInventory().setItem(slot,null);}
            }
        }
        if(amount==0){p.sendMessage("§cVocê não tem itens dessa categoria para vender.");return;}
        setMoney(p,getMoney(p)+total);p.sendMessage("§aVocê vendeu "+amount+" itens por $"+String.format(Locale.US,"%.2f",total)+" §7(50% do preço da loja).");
        if (!isBedrock(p)) openJavaMenu(p, "shopcat:" + category);
    }
    private void showRank(Player p, String type) {
        boolean kills = type.equalsIgnoreCase("kills");
        String field = kills ? "kills" : "money";
        List<String> ids = new ArrayList<>(playerData.getKeys(false));
        ids.removeIf(id -> {
            try { UUID.fromString(id); return false; }
            catch (IllegalArgumentException ex) { return true; }
        });
        ids.sort((a, b) -> Double.compare(playerData.getDouble(b + "." + field), playerData.getDouble(a + "." + field)));
        List<String> lines = new ArrayList<>();
        for (int i = 0; i < Math.min(10, ids.size()); i++) {
            String id = ids.get(i);
            OfflinePlayer offline = Bukkit.getOfflinePlayer(UUID.fromString(id));
            String name = offline.getName() == null ? "Jogador" : offline.getName();
            double value = playerData.getDouble(id + "." + field);
            String formatted = kills ? String.valueOf((int) value) : "$" + String.format(Locale.US, "%.2f", value);
            lines.add((i + 1) + ". " + name + " - " + formatted);
        }
        if (lines.isEmpty()) lines.add("Ainda não há dados neste ranking.");
        if (isBedrock(p)) {
            SimpleForm.Builder form = SimpleForm.builder().title(kills ? "TOP 10 KILLS" : "TOP 10 MONEY")
                    .content(String.join("\n", lines)).button("VOLTAR");
            form.validResultHandler(r -> openMain(p));
            FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
            return;
        }
        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 45, Component.text(kills ? "TOP 10 KILLS" : "TOP 10 MONEY"));
        holder.inventory = inv;
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, named(Material.BLACK_STAINED_GLASS_PANE, " ", ChatColor.BLACK));
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};
        for (int i = 0; i < lines.size() && i < 10; i++) {
            put(inv, holder, slots[i], Material.PAPER, "§l§e" + lines.get(i), "rank:info");
        }
        put(inv, holder, 40, Material.ARROW, "§l§0VOLTAR", "back");
        p.openInventory(inv);
    }

    private void updateTag(Player p){Scoreboard board=Bukkit.getScoreboardManager().getMainScoreboard();String teamName="ce"+p.getUniqueId().toString().substring(0,8);Team team=board.getTeam(teamName);if(team==null)team=board.registerNewTeam(teamName);for(String entry:new HashSet<>(team.getEntries()))team.removeEntry(entry);team.addEntry(p.getName());String clan=findClan(p.getUniqueId());Component prefix=Component.text("MEMBRO ",NamedTextColor.YELLOW).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD);if(clan!=null){int c=clanData.getInt(clan+".color",0);prefix=prefix.append(Component.text("["+clanData.getString(clan+".name", "CLAN")+"] ",toNamed(c)).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));}team.prefix(prefix);team.suffix(Component.empty());p.setScoreboard(board);}
    private NamedTextColor toNamed(int i){return switch(i){case 1->NamedTextColor.RED;case 2->NamedTextColor.BLUE;case 3->NamedTextColor.GREEN;case 4->NamedTextColor.LIGHT_PURPLE;case 5->NamedTextColor.AQUA;case 6->NamedTextColor.WHITE;default->NamedTextColor.YELLOW;};}

    private static final class InputSession {
        private final String type;
        private String value = "";
        private InputSession(String type) { this.type = type; }
    }
    private record TpaRequest(UUID requester, long createdAt) { }
    private static final class MenuHolder implements InventoryHolder { private Inventory inventory; private final Map<Integer,String> actions=new HashMap<>(); public Inventory getInventory(){return inventory;} }
}
