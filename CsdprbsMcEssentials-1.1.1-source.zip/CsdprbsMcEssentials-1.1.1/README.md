# CsdprbsMc Essentials — 1.1.1 (código-fonte)

Plugin para Paper 26.3, com menus Java e formulários Bedrock por Floodgate/Geyser.

## Requisitos para compilar e executar
- Paper 26.3 e Java 25 ou superior no servidor.
- JDK 25 para compilar.
- Gradle 9.1.0 ou superior.
- Floodgate instalado junto do Geyser para os formulários Bedrock.
- Conexão com a internet durante a compilação para baixar as dependências.

## Recursos presentes no código
- Bússola de Recuperação exclusiva para abrir o menu; protegida contra descarte, troca de mão e movimentação por inventário.
- Menu Java em inventário e menu Bedrock por formulários.
- Tema preto/amarelo e cores em negrito conforme especificado.
- TPA com seleção de jogadores online, ordem alfabética, paginação, aceitar/recusar, expiração de 60 segundos e cooldown de 15 segundos. Pedidos pendentes são preservados enquanto não expirarem, inclusive quando um jogador sai e volta.
- Até 5 homes por jogador; no Java, clique esquerdo teleporta/define e clique direito atualiza. No Bedrock, há botões separados.
- Clans de até 8 membros, convites, aceitar, sair/encerrar, escolha de cor e tags.
- Warps com paginação; administração para criar e remover warps.
- Rankings Top 10 de kills e saldo.
- Economia própria; loja por categorias, compra e venda (venda por 50% do preço de compra).
- Itens especiais limitados por jogador: name tag (2), sela (1), laço (4) e shulker shell (1).
- Painel administrativo protegido pela permissão `csdprbsmc.admin`.
- Dados persistidos em YAML (`players.yml`, `clans.yml`, `warps.yml`, `tpa.yml`).

## Compilar
Na pasta do projeto, com JDK 25 e Gradle 9.1 ou superior instalados:

```bash
gradle clean build
```

O arquivo será gerado em `build/libs/CsdprbsMcEssentials.jar`.

## Estado de validação — importante
Este pacote é **código-fonte**, não um `.jar` pronto. Foi feita uma revisão estática e corrigidos alguns fluxos de menus e persistência. A compilação real e os testes dentro de um servidor Paper 26.3 com Geyser/Floodgate ainda não foram executados. O ambiente usado nesta sessão só tem Java 21, não tem Gradle instalado e não consegue acessar a internet para baixar JDK 25 ou dependências. Portanto, não instale este projeto em seu servidor principal antes de compilar e testar em uma cópia/servidor de teste.
